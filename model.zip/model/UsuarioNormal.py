from . import Usuario as u
# from control.controlUser import UsuarioController

# control = UsuarioController()

class UsuarioNormal(u.Usuario):
    def gerenciarSeusComents(self):
        return
    
    def gerenciarSuasAvals(self):
        return
    

    #Area n sei se vai precisar:
    # def alterarSuasInfos(self):
    #     return
    
    # def buscarComent(self):
    #     return
    
    # def buscarAval(self):
    #     return